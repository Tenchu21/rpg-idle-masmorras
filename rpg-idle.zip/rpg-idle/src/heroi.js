// Herói sem classe: tudo vem dos atributos e do que está equipado.

export function novoHeroi(dados) {
  const equip = {};
  for (const slot of dados.regras.slots_heroi) equip[slot] = null;
  const heroi = {
    nivel: 1,
    xp: 0,
    pontos_livres: 0,
    atributos: { ...dados.atributos.inicial },
    equip,
    vida: 0,
  };
  heroi.vida = statsTotais(dados, heroi).vida_max;
  return heroi;
}

export const xpProximo = (dados, nivel) => dados.regras.progressao.xp_base * nivel * nivel;

// Soma atributos base + afixos + habilidades passivas dos itens equipados.
export function statsTotais(dados, heroi) {
  const f = dados.regras.formulas;
  const atr = { ...heroi.atributos };
  const bonus = { dano_pct: 0, velocidade_ataque_pct: 0, vida_pct: 0, esquiva_pct: 0, ouro_pct: 0, drop_pct: 0 };
  let danoArma = 0;
  let defesa = 0;
  let vidaExtra = 0;
  const habilidades = [];

  for (const item of Object.values(heroi.equip)) {
    if (!item) continue;
    const modelo = dados.porId.itens[item.modelo];
    danoArma += modelo.base.dano || 0;
    defesa += modelo.base.defesa || 0;
    vidaExtra += modelo.base.vida || 0;
    for (const af of item.afixos) {
      const def = dados.porId.afixos[af.id];
      if (def.tipo === 'atributo') atr[def.alvo] += af.valor;
      else bonus[def.alvo] += af.valor;
    }
    const hab = dados.porId.habilidades[modelo.habilidade];
    habilidades.push(hab.id);
    if (hab.uso === 'passiva') {
      bonus.ouro_pct += hab.efeito.ouro_pct || 0;
      bonus.drop_pct += hab.efeito.drop_pct || 0;
    }
  }

  const vidaMax = (f.vida_base + atr.vitalidade * f.vida_por_vit + vidaExtra) * (1 + bonus.vida_pct / 100);
  const intervaloBase = Math.max(f.intervalo_min_s, f.intervalo_base_s - atr.destreza * f.reducao_intervalo_por_des_s);
  return {
    atributos: atr,
    vida_max: Math.round(vidaMax),
    dano: (f.dano_base + atr.forca * f.dano_por_for + danoArma) * (1 + bonus.dano_pct / 100),
    intervalo_s: intervaloBase / (1 + bonus.velocidade_ataque_pct / 100),
    esquiva_pct: Math.min(f.esquiva_max_pct, atr.destreza * f.esquiva_por_des_pct + bonus.esquiva_pct),
    defesa,
    regen: f.regen_base + atr.vitalidade * f.regen_por_vit,
    ouro_pct: bonus.ouro_pct,
    drop_pct: bonus.drop_pct,
    habilidades, // os efeitos das habilidades entram no Dia 2 (combate); hoje só as passivas valem
  };
}

export function ganharXp(dados, heroi, xp) {
  let subiu = 0;
  heroi.xp += xp;
  while (heroi.nivel < dados.regras.progressao.nivel_max && heroi.xp >= xpProximo(dados, heroi.nivel)) {
    heroi.xp -= xpProximo(dados, heroi.nivel);
    heroi.nivel += 1;
    heroi.pontos_livres += dados.atributos.pontos_por_nivel;
    subiu += 1;
  }
  return subiu;
}
