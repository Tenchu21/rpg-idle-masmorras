import { carregarDados } from './dados.js';
import { criarRng } from './rng.js';
import { carregar, salvar, apagar } from './estado.js';
import { statsTotais } from './heroi.js';
import * as jogo from './jogo.js';
import { renderizar } from './ui.js';

const raiz = document.getElementById('app');

async function iniciar() {
  let dados;
  try {
    dados = await carregarDados();
  } catch (erro) {
    raiz.innerHTML = `<p class="erro">${erro.message}<br>Abra o jogo pelo servidor local (jogar.py), não direto pelo arquivo.</p>`;
    return;
  }

  const rng = criarRng();
  let estado = carregar() || jogo.novoEstado(dados);
  const ui = { auto: false, monstroId: 'slime_gelatinoso', log: ['Bem-vindo! Mate monstros, junte ouro e compre equipamento.'] };
  let timer = null;

  const registrar = (msg) => {
    if (!msg) return;
    ui.log.unshift(msg);
    ui.log.length = Math.min(ui.log.length, 12);
  };
  const atualizar = () => {
    salvar(estado);
    renderizar(raiz, dados, estado, ui);
  };

  function passoAuto() {
    const s = statsTotais(dados, estado.heroi);
    if (estado.pocoes > 0 && estado.heroi.vida < s.vida_max * 0.35) registrar(jogo.usarPocao(dados, estado));
    registrar(jogo.cacar(dados, estado, ui.monstroId, rng));
    atualizar();
  }

  const acoes = {
    cacar: () => registrar(jogo.cacar(dados, estado, ui.monstroId, rng)),
    auto: () => {
      ui.auto = !ui.auto;
      clearInterval(timer);
      if (ui.auto) timer = setInterval(passoAuto, 1500);
    },
    pocao: () => registrar(jogo.usarPocao(dados, estado)),
    equipar: (id) => registrar(jogo.equipar(dados, estado, id)),
    desequipar: (id) => registrar(jogo.desequipar(dados, estado, id)),
    vender: (id) => registrar(jogo.vender(dados, estado, id)),
    comprar: (id) => registrar(jogo.comprar(dados, estado, id, rng)),
    comprar_pocao: () => registrar(jogo.comprarPocao(dados, estado)),
    ponto: (id) => registrar(jogo.gastarPonto(dados, estado, id)),
    reiniciar: () => {
      if (!confirm('Apagar o save e recomeçar?')) return;
      apagar();
      estado = jogo.novoEstado(dados);
      ui.log = ['Novo começo. Boa sorte!'];
    },
  };

  raiz.addEventListener('click', (ev) => {
    const el = ev.target.closest('[data-acao]');
    if (!el || el.disabled) return;
    acoes[el.dataset.acao]?.(el.dataset.id);
    atualizar();
  });
  raiz.addEventListener('change', (ev) => {
    if (ev.target.id === 'monstro') ui.monstroId = ev.target.value;
  });

  atualizar();
}

iniciar();
