// Gera itens reais a partir dos modelos de data/itens.json.
// Modelo = o que o item é (habilidade, base). Item gerado = modelo + raridade + afixos sorteados.

export function gerarItem(dados, modeloId, raridadeId, rng) {
  const modelo = dados.porId.itens[modeloId];
  const raridade = dados.porId.raridades[raridadeId];
  const disponiveis = dados.afixos.afixos.filter((a) => a.slots.includes(modelo.slot));
  const afixos = [];
  for (let i = 0; i < raridade.afixos && disponiveis.length; i++) {
    const escolhido = rng.pesado(disponiveis);
    disponiveis.splice(disponiveis.indexOf(escolhido), 1); // sem afixo repetido no mesmo item
    const bruto = rng.int(escolhido.faixa[0], escolhido.faixa[1]) + modelo.nivel_req * escolhido.por_nivel;
    const valor =
      escolhido.tipo === 'atributo'
        ? Math.max(1, Math.round(bruto * raridade.mult))
        : Math.round(bruto * raridade.mult * 10) / 10;
    afixos.push({ id: escolhido.id, valor });
  }
  return {
    uid: `${Date.now().toString(36)}-${rng.int(0, 1679615).toString(36)}`,
    modelo: modeloId,
    raridade: raridadeId,
    refino: 0,
    afixos,
  };
}

export function valorVenda(dados, item) {
  const modelo = dados.porId.itens[item.modelo];
  const raridade = dados.porId.raridades[item.raridade];
  return Math.max(1, Math.round(modelo.preco_venda * raridade.mult_venda));
}

// Texto pronto para mostrar na tela.
export function descreverItem(dados, item) {
  const modelo = dados.porId.itens[item.modelo];
  const raridade = dados.porId.raridades[item.raridade];
  const hab = dados.porId.habilidades[modelo.habilidade];
  const linhas = [];
  if (modelo.base.dano) linhas.push(`Dano ${modelo.base.dano}`);
  if (modelo.base.defesa) linhas.push(`Defesa ${modelo.base.defesa}`);
  if (modelo.base.vida) linhas.push(`Vida +${modelo.base.vida}`);
  for (const af of item.afixos) {
    const def = dados.porId.afixos[af.id];
    linhas.push(def.tipo === 'atributo' ? `+${af.valor} ${def.rotulo}` : `+${af.valor}${def.rotulo}`);
  }
  return {
    nome: modelo.nome,
    cor: raridade.cor,
    raridade: raridade.nome,
    habilidade: `${hab.icone} ${hab.nome}${hab.uso === 'passiva' ? ' (passiva)' : ''}`,
    linhas,
    venda: valorVenda(dados, item),
  };
}
