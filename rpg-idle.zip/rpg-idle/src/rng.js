// Gerador aleatório com semente: o mesmo seed gera a mesma sequência (útil para testes).
export function criarRng(seed = Date.now()) {
  let a = seed >>> 0;
  const next = () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return {
    next,
    int: (min, max) => Math.floor(next() * (max - min + 1)) + min,
    chance: (pct) => next() * 100 < pct,
    pesado(lista, peso = (x) => x.peso) {
      const total = lista.reduce((s, x) => s + peso(x), 0);
      let r = next() * total;
      for (const x of lista) {
        r -= peso(x);
        if (r < 0) return x;
      }
      return lista[lista.length - 1];
    },
  };
}
