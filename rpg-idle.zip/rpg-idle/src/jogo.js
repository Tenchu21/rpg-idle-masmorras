// Regras do jogo: ações do jogador sobre o estado. Cada ação devolve uma frase para o registro.
import { novoHeroi, statsTotais, ganharXp } from './heroi.js';
import { gerarItem, valorVenda } from './itens.js';
import { simularLuta, calcularRecompensas } from './combate.js';

export function novoEstado(dados) {
  return {
    heroi: novoHeroi(dados),
    ouro: dados.regras.economia.ouro_inicial,
    pocoes: 0,
    inventario: [],
    vitorias: 0,
    mortes: 0,
  };
}

const nomeItem = (dados, item) => dados.porId.itens[item.modelo].nome;
const mochilaCheia = (dados, estado) => estado.inventario.length >= dados.regras.economia.inventario_max;

export function cacar(dados, estado, monstroId, rng) {
  const monstro = dados.porId.monstros[monstroId];
  const stats = statsTotais(dados, estado.heroi);
  const luta = simularLuta(dados, stats, estado.heroi.vida, monstro, rng);

  if (luta.resultado === 'derrota') {
    estado.mortes += 1;
    estado.heroi.vida = stats.vida_max; // regra provisória de morte
    return `☠️ ${monstro.icone} ${monstro.nome} venceu. Você voltou à vila com a vida cheia.`;
  }
  if (luta.resultado === 'empate') {
    estado.heroi.vida = luta.vida;
    return `⏱️ A luta contra ${monstro.nome} durou demais e você fugiu.`;
  }

  const rec = calcularRecompensas(dados, monstro, stats, rng);
  estado.vitorias += 1;
  estado.ouro += rec.ouro;
  const subiu = ganharXp(dados, estado.heroi, rec.xp);
  const novaMax = statsTotais(dados, estado.heroi).vida_max;
  const descanso = dados.regras.combate.descanso_entre_lutas_s * stats.regen;
  estado.heroi.vida = Math.min(novaMax, luta.vida + descanso);

  let msg = `⚔️ ${monstro.icone} ${monstro.nome} derrotado: +${rec.ouro} ouro, +${rec.xp} XP`;
  if (rec.item) {
    if (mochilaCheia(dados, estado)) {
      estado.ouro += valorVenda(dados, rec.item);
      msg += ` · mochila cheia, ${nomeItem(dados, rec.item)} vendido automaticamente`;
    } else {
      estado.inventario.push(rec.item);
      msg += ` · 🎁 ${nomeItem(dados, rec.item)} (${dados.porId.raridades[rec.item.raridade].nome})`;
    }
  }
  if (subiu) msg += ` · ⬆️ nível ${estado.heroi.nivel}!`;
  return msg;
}

export function equipar(dados, estado, uid) {
  const idx = estado.inventario.findIndex((i) => i.uid === uid);
  if (idx < 0) return null;
  const item = estado.inventario[idx];
  const slot = dados.porId.itens[item.modelo].slot;
  let alvo = slot;
  if (slot === 'acessorio') alvo = !estado.heroi.equip.acessorio1 ? 'acessorio1' : !estado.heroi.equip.acessorio2 ? 'acessorio2' : 'acessorio1';
  const anterior = estado.heroi.equip[alvo];
  estado.inventario.splice(idx, 1);
  if (anterior) estado.inventario.push(anterior);
  estado.heroi.equip[alvo] = item;
  estado.heroi.vida = Math.min(estado.heroi.vida, statsTotais(dados, estado.heroi).vida_max);
  return `🧰 Equipou ${nomeItem(dados, item)}.`;
}

export function desequipar(dados, estado, slot) {
  const item = estado.heroi.equip[slot];
  if (!item) return null;
  if (mochilaCheia(dados, estado)) return '🎒 Mochila cheia.';
  estado.heroi.equip[slot] = null;
  estado.inventario.push(item);
  estado.heroi.vida = Math.min(estado.heroi.vida, statsTotais(dados, estado.heroi).vida_max);
  return `🎒 Guardou ${nomeItem(dados, item)}.`;
}

export function vender(dados, estado, uid) {
  const idx = estado.inventario.findIndex((i) => i.uid === uid);
  if (idx < 0) return null;
  const [item] = estado.inventario.splice(idx, 1);
  const ouro = valorVenda(dados, item);
  estado.ouro += ouro;
  return `🪙 Vendeu ${nomeItem(dados, item)} por ${ouro} ouro.`;
}

export function comprar(dados, estado, modeloId, rng) {
  const modelo = dados.porId.itens[modeloId];
  if (estado.ouro < modelo.preco_compra) return `Ouro insuficiente para ${modelo.nome} (${modelo.preco_compra}).`;
  if (mochilaCheia(dados, estado)) return '🎒 Mochila cheia.';
  estado.ouro -= modelo.preco_compra;
  estado.inventario.push(gerarItem(dados, modeloId, 'comum', rng));
  return `🛒 Comprou ${modelo.nome} por ${modelo.preco_compra} ouro.`;
}

export function comprarPocao(dados, estado) {
  const p = dados.regras.economia.pocao_vida;
  if (estado.ouro < p.preco) return `Ouro insuficiente para a poção (${p.preco}).`;
  estado.ouro -= p.preco;
  estado.pocoes += 1;
  return `🧪 Comprou uma poção de vida por ${p.preco} ouro.`;
}

export function usarPocao(dados, estado) {
  if (estado.pocoes <= 0) return 'Você não tem poções.';
  const max = statsTotais(dados, estado.heroi).vida_max;
  if (estado.heroi.vida >= max) return 'Sua vida já está cheia.';
  estado.pocoes -= 1;
  estado.heroi.vida = Math.min(max, estado.heroi.vida + dados.regras.economia.pocao_vida.cura);
  return `🧪 Poção usada: +${dados.regras.economia.pocao_vida.cura} de vida.`;
}

export function gastarPonto(dados, estado, atributo) {
  if (estado.heroi.pontos_livres <= 0 || !(atributo in estado.heroi.atributos)) return null;
  estado.heroi.pontos_livres -= 1;
  estado.heroi.atributos[atributo] += 1;
  return `+1 ${dados.porId.atributos[atributo].sigla}.`;
}
