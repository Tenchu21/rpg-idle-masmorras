// Combate do Dia 1: só ataques básicos, resolvido em passos de 0,1 s.
// Dia 2 troca isto pelo motor completo (habilidades, recargas, efeitos).
import { gerarItem } from './itens.js';

export function simularLuta(dados, stats, vidaInicial, monstro, rng) {
  const passo = dados.regras.combate.passo_s;
  const limite = dados.regras.combate.tempo_max_luta_s;
  let t = 0;
  let vida = vidaInicial;
  let vidaMonstro = monstro.vida;
  let proxHeroi = stats.intervalo_s;
  let proxMonstro = monstro.intervalo_s;
  let esquivas = 0;

  while (vida > 0 && vidaMonstro > 0 && t < limite) {
    t = Math.round((t + passo) * 1000) / 1000;
    vida = Math.min(stats.vida_max, vida + stats.regen * passo);
    if (t >= proxHeroi) {
      vidaMonstro -= stats.dano;
      proxHeroi += stats.intervalo_s;
    }
    if (vidaMonstro <= 0) break;
    if (t >= proxMonstro) {
      if (rng.chance(stats.esquiva_pct)) esquivas += 1;
      else vida -= Math.max(1, monstro.dano - stats.defesa);
      proxMonstro += monstro.intervalo_s;
    }
  }
  const resultado = vidaMonstro <= 0 ? 'vitoria' : vida <= 0 ? 'derrota' : 'empate';
  return { resultado, vida: Math.max(0, Math.round(vida * 10) / 10), duracao_s: t, esquivas };
}

export function calcularRecompensas(dados, monstro, stats, rng) {
  const ouro = Math.round(rng.int(monstro.ouro[0], monstro.ouro[1]) * (1 + stats.ouro_pct / 100));
  let item = null;
  if (rng.chance(monstro.drop_item_pct * (1 + stats.drop_pct / 100))) {
    const alvo = rng.pesado(monstro.drops);
    const raridade = rng.pesado(dados.regras.raridades);
    item = gerarItem(dados, alvo.item, raridade.id, rng);
  }
  return { ouro, xp: monstro.xp, item };
}
