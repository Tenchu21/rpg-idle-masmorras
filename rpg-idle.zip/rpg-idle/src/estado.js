// Salvamento no navegador (localStorage). Tudo protegido: pode estar bloqueado ou vazio.
const CHAVE = 'rpgidle.save.v1';

export function salvar(estado) {
  try {
    localStorage.setItem(CHAVE, JSON.stringify(estado));
  } catch {
    /* sem armazenamento: o jogo continua, só não salva */
  }
}

export function carregar() {
  try {
    const bruto = localStorage.getItem(CHAVE);
    return bruto ? JSON.parse(bruto) : null;
  } catch {
    return null;
  }
}

export function apagar() {
  try {
    localStorage.removeItem(CHAVE);
  } catch {
    /* ignora */
  }
}
