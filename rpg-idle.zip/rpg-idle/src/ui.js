// Tela: redesenha tudo a cada mudança (simples e suficiente para o Dia 1).
import { statsTotais, xpProximo } from './heroi.js';
import { descreverItem } from './itens.js';

const NOMES_SLOT = {
  arma: 'Arma', capacete: 'Capacete', armadura: 'Armadura', botas: 'Botas',
  acessorio1: 'Acessório 1', acessorio2: 'Acessório 2',
};

const fmt = (n) => (Math.round(n * 10) / 10).toString();

function cartaoItem(dados, item, botoes) {
  const d = descreverItem(dados, item);
  return `<div class="item" style="border-color:${d.cor}">
    <b style="color:${d.cor}">${d.nome}</b> <small>${d.raridade}</small>
    <div class="hab">${d.habilidade}</div>
    <div class="linhas">${d.linhas.join(' · ')}</div>
    <div class="botoes">${botoes(d)}</div>
  </div>`;
}

export function renderizar(raiz, dados, estado, ui) {
  const h = estado.heroi;
  const s = statsTotais(dados, h);
  const e = dados.regras.economia;

  const atributos = dados.atributos.atributos
    .map((a) => `<li><b>${a.sigla}</b> ${s.atributos[a.id]}${h.pontos_livres > 0 ? ` <button data-acao="ponto" data-id="${a.id}">+</button>` : ''}</li>`)
    .join('');

  const equip = dados.regras.slots_heroi
    .map((slot) => {
      const item = h.equip[slot];
      const corpo = item
        ? cartaoItem(dados, item, () => `<button data-acao="desequipar" data-id="${slot}">Guardar</button>`)
        : '<div class="vazio">vazio</div>';
      return `<div class="slot"><div class="rotulo">${NOMES_SLOT[slot]}</div>${corpo}</div>`;
    })
    .join('');

  const monstros = dados.monstros.monstros
    .filter((m) => !m.chefe)
    .map((m) => `<option value="${m.id}" ${m.id === ui.monstroId ? 'selected' : ''}>${m.icone} ${m.nome} (nv ${m.nivel})</option>`)
    .join('');

  const mochila = estado.inventario.length
    ? estado.inventario
        .map((item) => cartaoItem(dados, item, (d) => `<button data-acao="equipar" data-id="${item.uid}">Equipar</button><button data-acao="vender" data-id="${item.uid}">Vender ${d.venda}🪙</button>`))
        .join('')
    : '<div class="vazio">A mochila está vazia. Vá caçar!</div>';

  const loja = e.loja
    .map((id) => {
      const m = dados.porId.itens[id];
      const hab = dados.porId.habilidades[m.habilidade];
      return `<div class="item"><b>${m.nome}</b> <small>${hab.icone} ${hab.nome}</small>
        <div class="linhas">${m.base.dano ? `Dano ${m.base.dano}` : ''}${m.base.defesa ? `Defesa ${m.base.defesa}` : ''}${m.base.vida ? `Vida +${m.base.vida}` : ''}</div>
        <div class="botoes"><button data-acao="comprar" data-id="${id}" ${estado.ouro < m.preco_compra ? 'disabled' : ''}>Comprar ${m.preco_compra}🪙</button></div></div>`;
    })
    .join('');

  raiz.innerHTML = `
  <header><h1>RPG Idle de Masmorras <small>Dia 1 · esqueleto</small></h1>
    <div class="topo">🪙 ${estado.ouro} · 🧪 ${estado.pocoes} · vitórias ${estado.vitorias} · mortes ${estado.mortes}</div></header>
  <main>
    <section><h2>Herói · nível ${h.nivel}</h2>
      <div class="barra"><div style="width:${Math.min(100, (h.vida / s.vida_max) * 100)}%"></div><span>Vida ${Math.round(h.vida)} / ${s.vida_max}</span></div>
      <div class="barra xp"><div style="width:${Math.min(100, (h.xp / xpProximo(dados, h.nivel)) * 100)}%"></div><span>XP ${h.xp} / ${xpProximo(dados, h.nivel)}</span></div>
      ${h.pontos_livres > 0 ? `<p class="aviso">Você tem ${h.pontos_livres} ponto(s) para distribuir.</p>` : ''}
      <ul class="atributos">${atributos}</ul>
      <p class="stats">Dano ${fmt(s.dano)} · Ataque a cada ${fmt(s.intervalo_s)}s · Esquiva ${fmt(s.esquiva_pct)}% · Defesa ${s.defesa} · Regen ${fmt(s.regen)}/s · Ouro +${s.ouro_pct}% · Drop +${s.drop_pct}%</p>
      <div class="slots">${equip}</div>
    </section>
    <section><h2>Caçada</h2>
      <select id="monstro">${monstros}</select>
      <div class="botoes grande">
        <button data-acao="cacar">Caçar uma vez</button>
        <button data-acao="auto" class="${ui.auto ? 'ligado' : ''}">${ui.auto ? '⏸ Parar caça automática' : '▶ Caça automática'}</button>
        <button data-acao="pocao" ${estado.pocoes <= 0 ? 'disabled' : ''}>Usar poção</button>
      </div>
      <h2>Registro</h2><ul class="log">${ui.log.map((l) => `<li>${l}</li>`).join('')}</ul>
    </section>
    <section><h2>Mochila (${estado.inventario.length}/${e.inventario_max})</h2><div class="lista">${mochila}</div></section>
    <section><h2>Loja da vila</h2>
      <div class="botoes"><button data-acao="comprar_pocao" ${estado.ouro < e.pocao_vida.preco ? 'disabled' : ''}>🧪 Poção de vida (+${e.pocao_vida.cura}) · ${e.pocao_vida.preco}🪙</button></div>
      <div class="lista">${loja}</div>
      <p class="rodape"><button data-acao="reiniciar" class="perigo">Apagar save e recomeçar</button></p>
    </section>
  </main>`;
}
