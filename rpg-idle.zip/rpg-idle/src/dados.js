// Carrega os arquivos JSON de data/ e cria índices por id.
const ARQUIVOS = ['regras', 'atributos', 'habilidades', 'itens', 'afixos', 'monstros'];

export async function carregarDados(base = 'data/') {
  const bruto = {};
  for (const nome of ARQUIVOS) {
    const resp = await fetch(`${base}${nome}.json`);
    if (!resp.ok) throw new Error(`Não consegui carregar ${nome}.json (${resp.status})`);
    bruto[nome] = await resp.json();
  }
  return indexar(bruto);
}

const porId = (lista) => Object.fromEntries(lista.map((x) => [x.id, x]));

export function indexar(bruto) {
  return {
    ...bruto,
    porId: {
      atributos: porId(bruto.atributos.atributos),
      habilidades: porId(bruto.habilidades.habilidades),
      itens: porId(bruto.itens.itens),
      afixos: porId(bruto.afixos.afixos),
      monstros: porId(bruto.monstros.monstros),
      raridades: porId(bruto.regras.raridades),
    },
  };
}
