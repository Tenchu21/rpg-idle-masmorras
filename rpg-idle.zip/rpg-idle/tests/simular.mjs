// Simula o ciclo matar -> ouro -> comprar -> equipar, sem navegador. Uso: node tests/simular.mjs
import { readFileSync } from 'node:fs';
import { indexar } from '../src/dados.js';
import { criarRng } from '../src/rng.js';
import * as jogo from '../src/jogo.js';
import { statsTotais } from '../src/heroi.js';
import { gerarItem, descreverItem } from '../src/itens.js';

const ler = (n) => JSON.parse(readFileSync(new URL(`../data/${n}.json`, import.meta.url), 'utf8'));
const dados = indexar(Object.fromEntries(['regras', 'atributos', 'habilidades', 'itens', 'afixos', 'monstros'].map((n) => [n, ler(n)])));
const rng = criarRng(42);

// 1) Exemplo de item sorteado (raro = 2 afixos)
const exemplo = gerarItem(dados, 'punhal_do_pantano', 'raro', rng);
const d = descreverItem(dados, exemplo);
console.log(`Exemplo: ${d.nome} (${d.raridade}) | ${d.habilidade} | ${d.linhas.join(' · ')}\n`);

// 2) Distribuição de raridade em 10 mil drops
const cont = {};
for (let i = 0; i < 10000; i++) { const r = rng.pesado(dados.regras.raridades).id; cont[r] = (cont[r] || 0) + 1; }
console.log('Raridade em 10 mil drops:', cont, '\n');

// 3) Um herói jogando 300 lutas, comprando e equipando o que dá
const estado = jogo.novoEstado(dados);
const cacar = ['slime_gelatinoso', 'rato_de_esgoto'];
let compras = 0;
for (let i = 1; i <= 300; i++) {
  const alvo = estado.heroi.nivel >= 3 ? 'goblin_ladrao' : cacar[i % 2];
  jogo.cacar(dados, estado, alvo, rng);
  for (const it of [...estado.inventario]) {
    const m = dados.porId.itens[it.modelo];
    if (!estado.heroi.equip[m.slot] || (m.slot === 'acessorio' && !estado.heroi.equip.acessorio2)) jogo.equipar(dados, estado, it.uid);
    else if (estado.inventario.length > 8) jogo.vender(dados, estado, it.uid);
  }
  for (const id of dados.regras.economia.loja) {
    const m = dados.porId.itens[id];
    if (m.slot !== 'acessorio' && !estado.heroi.equip[m.slot] && estado.ouro >= m.preco_compra) { jogo.comprar(dados, estado, id, rng); compras++; }
  }
  while (estado.heroi.pontos_livres > 0) jogo.gastarPonto(dados, estado, ['forca', 'vitalidade', 'destreza'][estado.heroi.pontos_livres % 3]);
}
const s = statsTotais(dados, estado.heroi);
console.log(`Após 300 lutas: nível ${estado.heroi.nivel}, ouro ${estado.ouro}, vitórias ${estado.vitorias}, mortes ${estado.mortes}, compras ${compras}`);
console.log(`Stats: vida ${s.vida_max}, dano ${s.dano.toFixed(1)}, defesa ${s.defesa}, ataque a cada ${s.intervalo_s.toFixed(2)}s`);
console.log('Equipado:', Object.entries(estado.heroi.equip).filter(([, v]) => v).map(([k, v]) => `${k}=${dados.porId.itens[v.modelo].nome}`).join(', '));

if (estado.vitorias < 100) { console.error('FALHA: poucas vitórias, ciclo quebrado'); process.exit(1); }
console.log('\nCiclo OK.');
