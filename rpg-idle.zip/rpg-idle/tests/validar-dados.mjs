// Confere os dados do Dia 1. Uso: node tests/validar-dados.mjs
import { readFileSync } from 'node:fs';
import { indexar } from '../src/dados.js';

const ler = (n) => JSON.parse(readFileSync(new URL(`../data/${n}.json`, import.meta.url), 'utf8'));
const dados = indexar(Object.fromEntries(['regras', 'atributos', 'habilidades', 'itens', 'afixos', 'monstros'].map((n) => [n, ler(n)])));

const erros = [];
const checar = (cond, msg) => { if (!cond) erros.push(msg); };

checar(dados.atributos.atributos.length === 4, 'devem existir 4 atributos');
checar(dados.itens.itens.length === 20, `devem existir 20 itens (há ${dados.itens.itens.length})`);
checar(dados.habilidades.habilidades.length === 8, 'devem existir 8 habilidades');

const ids = (lista) => lista.map((x) => x.id);
for (const [nome, lista] of Object.entries({ itens: dados.itens.itens, habilidades: dados.habilidades.habilidades, monstros: dados.monstros.monstros, afixos: dados.afixos.afixos })) {
  checar(new Set(ids(lista)).size === lista.length, `ids repetidos em ${nome}`);
}

const slots = dados.regras.slots_item;
for (const it of dados.itens.itens) {
  const hab = dados.porId.habilidades[it.habilidade];
  checar(!!hab, `${it.id}: habilidade "${it.habilidade}" não existe`);
  if (!hab) continue;
  checar(hab.familias_compativeis.includes(it.familia), `${it.id}: família "${it.familia}" incompatível com ${hab.id}`);
  checar(hab.slots_compativeis.includes(it.slot), `${it.id}: slot "${it.slot}" incompatível com ${hab.id}`);
  checar(slots.includes(it.slot), `${it.id}: slot inválido`);
  checar(it.preco_compra > it.preco_venda, `${it.id}: preço de venda deve ser menor que o de compra`);
}

const dropsPossiveis = new Set();
for (const m of dados.monstros.monstros) {
  for (const d of m.drops) {
    checar(!!dados.porId.itens[d.item], `${m.id}: drop "${d.item}" não existe`);
    dropsPossiveis.add(d.item);
  }
}
for (const it of dados.itens.itens) checar(dropsPossiveis.has(it.id), `${it.id}: nenhum monstro dropa este item`);
for (const id of dados.regras.economia.loja) checar(!!dados.porId.itens[id], `loja: "${id}" não existe`);
for (const a of dados.afixos.afixos) for (const s of a.slots) checar(slots.includes(s), `afixo ${a.id}: slot "${s}" inválido`);
for (const s of slots) checar(dados.afixos.afixos.some((a) => a.slots.includes(s)), `nenhum afixo para o slot ${s}`);

// Resumo habilidade -> itens
const resumo = {};
for (const it of dados.itens.itens) (resumo[it.habilidade] ||= []).push(it.nome);
for (const h of dados.habilidades.habilidades) checar((resumo[h.id] || []).length >= 2, `${h.id}: deve estar em pelo menos 2 itens`);

if (erros.length) {
  console.error('ERROS:\n- ' + erros.join('\n- '));
  process.exit(1);
}
console.log('Dados OK: 4 atributos, 20 itens, 8 habilidades.\n');
for (const [h, itens] of Object.entries(resumo)) console.log(`${h.padEnd(16)} ${itens.length} itens: ${itens.join(', ')}`);
